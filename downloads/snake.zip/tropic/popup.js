const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
const box = 40; // Increase the size of the box
canvas.width = 400; // Adjust canvas width
canvas.height = 400; // Adjust canvas height
let score = 0;
let snake;
let direction;
let food;
let game;
let headImage = new Image();

// Initialize the game
function initGame() {
    score = 0;
    snake = [{ x: 4 * box, y: 4 * box }]; // Adjust starting position
    direction = "RIGHT"; // Set initial direction
    spawnFood(); // Spawn the food
    document.getElementById("score").innerText = score;
    clearInterval(game); // Clear any existing game loop
    game = setInterval(draw, 100); // Increase interval time to make the snake move slower
}

// Spawn food at random position
function spawnFood() {
    food = {
        x: Math.floor(Math.random() * (canvas.width / box)) * box,
        y: Math.floor(Math.random() * (canvas.height / box)) * box
    };
}

// Handle keyboard input
document.addEventListener("keydown", directionControl);
document.getElementById("restart").addEventListener("click", initGame);
document.getElementById("headImageInput").addEventListener("change", function(event) {
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            headImage.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Control the snake's direction
function directionControl(event) {
    if (event.key === "ArrowLeft" && direction !== "RIGHT") {
        direction = "LEFT";
    } else if (event.key === "ArrowUp" && direction !== "DOWN") {
        direction = "UP";
    } else if (event.key === "ArrowRight" && direction !== "LEFT") {
        direction = "RIGHT";
    } else if (event.key === "ArrowDown" && direction !== "UP") {
        direction = "DOWN";
    }
}

// Draw the game elements
function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    // Draw the snake
    for (let i = 0; i < snake.length; i++) {
        if (i === 0 && headImage.src) {
            ctx.drawImage(headImage, snake[i].x, snake[i].y, box, box);
        } else {
            ctx.fillStyle = (i === 0) ? "green" : "lightgreen"; // Head is green, body is light green
            ctx.fillRect(snake[i].x, snake[i].y, box, box);
            ctx.strokeStyle = "darkgreen"; // Outline color
            ctx.strokeRect(snake[i].x, snake[i].y, box, box);
        }
    }

    // Draw the food
    ctx.fillStyle = "red";
    ctx.fillRect(food.x, food.y, box, box);

    let snakeX = snake[0].x;
    let snakeY = snake[0].y;

    // Check for food collision
    if (snakeX === food.x && snakeY === food.y) {
        score++;
        document.getElementById("score").innerText = score;

        // Generate new food position
        spawnFood();
    } else {
        snake.pop(); // Remove the last part of the snake
    }

    // Move the snake in the current direction
    if (direction === "LEFT") snakeX -= box;
    if (direction === "UP") snakeY -= box;
    if (direction === "RIGHT") snakeX += box;
    if (direction === "DOWN") snakeY += box;

    const newHead = { x: snakeX, y: snakeY };
    snake.unshift(newHead);

    // Check for collisions with walls or self
    if (
        snake[0].x < 0 || 
        snake[0].x >= canvas.width || 
        snake[0].y < 0 || 
        snake[0].y >= canvas.height || 
        collision(snake)
    ) {
        clearInterval(game);
        alert("Game Over! Your score was: " + score);
    }
}

// Check for self-collision
function collision(snake) {
    for (let i = 1; i < snake.length; i++) {
        if (snake[i].x === snake[0].x && snake[i].y === snake[0].y) {
            return true;
        }
    }
    return false;
}

// Start the game for the first time
initGame();